import { jsxs as _jsxs } from "react/jsx-runtime";
import { Typography } from '@mui/material';
export default function Footer() {
    return (_jsxs(Typography, Object.assign({ variant: 'body2', color: 'textSecondary', align: 'center' }, { children: ["Irontec \u00A0", new Date().getFullYear()] })));
}
