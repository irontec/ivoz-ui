/* eslint-disable no-script-url */
import { useState, useEffect } from 'react';
import { criteriaToArray, stringToCriteria } from './List.helpers';
const useQueryStringParams = function () {
    const [currentQueryParams, setCurrentQueryParams] = useState([]);
    const uri = location.search;
    useEffect(() => {
        const uriCriteria = stringToCriteria(uri);
        setCurrentQueryParams(criteriaToArray(uriCriteria));
    }, [uri]);
    return currentQueryParams;
};
export default useQueryStringParams;
