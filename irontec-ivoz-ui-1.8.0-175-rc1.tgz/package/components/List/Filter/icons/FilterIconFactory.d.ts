/// <reference types="react" />
export declare type OrderFilterType = string;
export declare type SearchFilterType = OrderFilterType | '' | 'exists' | 'partial' | 'start' | 'end' | 'in' | 'exact' | 'eq' | 'neq' | 'lt' | 'lte' | 'gt' | 'gte' | 'between';
interface FilterIconFactoryProps {
    name: SearchFilterType;
    className?: string;
    fontSize?: 'small' | 'inherit' | 'large' | 'medium' | undefined;
    includeLabel?: boolean;
}
export default function FilterIconFactory(props: FilterIconFactoryProps): JSX.Element;
export declare const getFilterLabel: (value: string) => JSX.Element;
export {};
